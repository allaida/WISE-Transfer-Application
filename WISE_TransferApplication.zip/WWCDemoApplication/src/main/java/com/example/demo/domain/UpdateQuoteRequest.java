package com.example.demo.domain;

public class UpdateQuoteRequest {
    String targetAccount;
}
